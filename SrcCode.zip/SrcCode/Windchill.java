import  java.util.Scanner;
public class Windchill {

	public static void main(String[] args) {
		Scanner userInput = new Scanner(System.in);
		System.out.println("-------WIND CHILL CALCULATOR--------");
		System.out.println("Enter the value for temperature in in F, the value must be between -45 and 40.");
		double Temp;
		Temp=userInput.nextDouble();
		System.out.println("Enter the value for wind chill in MPH, the value must be between 5 and 60.");
		double Chill;
		Chill=userInput.nextDouble();
		double Finalchill;
		Finalchill= (35.74 + (0.6215*Temp) - 35.75*(Math.pow(Chill,0.16)) + (0.4275*Temp*(Math.pow(Chill, 0.16))));
				 
				//V is the Wind Speed in MPH, and 
				 // T is the temperature in degrees F.
		System.out.println("The wind chill is " + Finalchill + " degrees");
		
		
		System.out.println("Programmer:Omeed Zarrabian");
		userInput.close();

		
		
		

	}

}
